Place the original IBM Telco Customer Churn CSV here and name it Telco-Customer-Churn.csv. Dataset not redistributed in this portfolio package.
